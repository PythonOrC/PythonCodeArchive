#导入直接启动、窗体属性设置模块
import direct.directbase.DirectStart
from panda3d.core import *
#创建窗体属性容器，并修改标题、尺寸等属性
window = WindowProperties()
window.setTitle("Agility Training")
window.setSize(1200, 800)
#将属性传递给主窗体
base.win.requestProperties(window)
#加载并显示场景模型文件
scene = loader.loadModel("woodland")
scene.reparentTo(render)
#设置镜头位置及角度
base.cam.setPos(0, -1200, 1200)
base.cam.setHpr(0, -45, 0)
base.disableMouse()
#设置窗体背景色
base.setBackgroundColor(0/255, 128/255, 255/255)

#运行主程序
base.run()
